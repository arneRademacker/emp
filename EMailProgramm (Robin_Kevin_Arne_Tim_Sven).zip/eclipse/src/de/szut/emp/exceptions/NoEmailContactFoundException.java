package de.szut.emp.exceptions;

public class NoEmailContactFoundException extends Exception {

}
