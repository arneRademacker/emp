package de.szut.emp.exceptions;

public class NoPreviousEmailFoundException extends NoEmailContactFoundException {

}
