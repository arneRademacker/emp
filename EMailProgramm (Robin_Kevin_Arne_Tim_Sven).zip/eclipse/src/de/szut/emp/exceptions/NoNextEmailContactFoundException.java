package de.szut.emp.exceptions;

public class NoNextEmailContactFoundException extends NoEmailContactFoundException {

}
